import math
def area(r):
	return math.pi*r*r
def perim(r):
	return 2*math.pi*r
