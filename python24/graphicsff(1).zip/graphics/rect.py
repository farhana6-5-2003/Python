def area(l,b):
	return l*b
def perim(l,b):
	return 2*(l+b)
