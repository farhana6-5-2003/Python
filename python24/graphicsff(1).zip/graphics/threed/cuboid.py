def surarea(l,b,h):
	return 2*(l*b+b*h+h*l)
def vol(l,b,h):
	return l*b*h
