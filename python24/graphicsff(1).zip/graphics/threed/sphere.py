import math
def surarea(r):
	return 4*math.pi*r*r
def perim(r):
	return (4/3)*pi*r*r
