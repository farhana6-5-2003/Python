#CO-1
#DATE : 01-10-2024
#11.Find biggest of 3 numbers entered.

#PROGRAM
a=int(input("Enter first number:"))
b=int(input("Enter second number:"))
c=int(input("Enter third number:"))
if a>b and a>c:
	print(a,"is the largest")
elif b>c:
	print(b,"is the largest")
else:
	print(c,"is the largest")
	
#OUTPUT
#Enter first number : 76
#Enter second number: 14
#Enter third number : 5
#76 is the largest

#Enter first number : 34
#Enter second number: 145
#Enter third number : 50
#145 is the largest

#Enter first number : 12
#Enter second number: 15
#Enter third number : 23
#23 is the largest



 	
