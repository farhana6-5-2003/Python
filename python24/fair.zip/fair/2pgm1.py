#DATE : 08-10-2024
#Program to find the factorial of a number

#PROGRAM
x=int(input("Enter a number:"))
f=1
i=1
while i<=x:
 	f=f*i
 	i=i+1
print("The factorial of",x,"is",f)

#OUTPUT
#Enter a number:6
#The factorial of 6 is 720

#Enter a number:8
#The factorial of 8 is 40320
 
