#DATE:29-10-2024
#Find gcd of 2 numbers


#PROGRAM
import math
x=int(input("Enter number1:"))
y=int(input("Enter number2:"))
print("Gcd of 2 numbers is : ",math.gcd(x,y))

#OUTPUT
#Enter number1:10
#Enter number2:25
#Gcd of 2 numbers is :  5

