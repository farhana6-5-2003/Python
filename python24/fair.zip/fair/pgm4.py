#DATE:29-10-2024
#4. Count the occurrences of each word in a line of text.
