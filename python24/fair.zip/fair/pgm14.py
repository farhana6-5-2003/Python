#CO-1
#DATE : 03-10-2024
# 14.Accept an integer n and compute n+nn+nnn.

#PROGRAM
n=int(input("Enter value for n:"))
c=n+(n*11)+(n*111)
print(c)

#OUTPUT
#Enter value for n :3
#369

#Enter value for n:
#1107
