#CO-1
#DATE : 01-10-2024
#10.Accept the radius from user and find area of circle.

#PROGRAM
r=float(input("Enter radius of the circle:"))
area=float(3.14*r*r)
print("Area of circle is ",area,"cm^2")


#OUTPUT
#Enter radius of the circle: 2
#Area of circle is 12.56 cm^2

#Enter radius of the circle: 15
#Area of circle is 706.5 cm^2
